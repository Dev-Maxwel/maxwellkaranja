var sidebar = document.getElementById("tmsb");
   function showMenu(){
      tmsb.style.display = "none";
   }
   
   function hideMenu(){
      tmsb.style.top = "1px";
   }
   


var typed = new Typed(".input", {
strings:["Maxwell Karanja.",  "a Full Stack Software Engineer.", "a Web developer.", "a Content Writer & blogger", "an IT enthusiast"],
typeSpeed: 150,
backSpeed: 15,
loop: true,
})
